const express = require('express');
const nodemailer = require('nodemailer');
const app = express();

app.use(express.json());

// Create a transporter using SMTP
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'your-email@gmail.com',
        pass: 'your-app-specific-password'
    }
});

app.post('/send-email', async (req, res) => {
    const { name, email, message } = req.body;
    
    const mailOptions = {
        from: email,
        to: 'gollaganesh2004@gmail.com',
        subject: `Portfolio Contact from ${name}`,
        text: `
Name: ${name}
Email: ${email}
Message: ${message}
`
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).json({ message: 'Email sent successfully' });
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ error: 'Failed to send email' });
    }
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});